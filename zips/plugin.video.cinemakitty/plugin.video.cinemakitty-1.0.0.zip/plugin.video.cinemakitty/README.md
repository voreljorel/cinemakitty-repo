# CinemaKitty

Doplněk pro Kodi, který umožňuje přehrávat filmy přímo z Webshare.cz (vyžaduje VIP účet).

## ✨ Funkce
- Automatické přihlášení k Webshare API
- Vyhledávání a přehrávání filmů přes Webshare
- Napojení na TMDb: top filmy, populární, žánry, seriály
- Výběr kvality (1080p / 720p / bez filtru)
- Oblíbené filmy

## Autor
David Kotek (VorelJorel)
